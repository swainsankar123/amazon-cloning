#include <stdio.h>
int main()
{
     int x;
     printf("enter a number ");
     scanf("%d", &x);
     printf("the squre is =");
     printf("%d", x*x);





}